import React, { useState, useEffect, useMemo, useRef } from "react";
import * as XLSX from "xlsx";
import {
  Search, Plus, Upload, Download, Camera, X, Wine, Trash2,
  Pencil, Check, Loader2, FileSpreadsheet, AlertCircle, ArrowUpDown,
  MapPin, ExternalLink, MoreHorizontal, Layers, Save, Clipboard
} from "lucide-react";

const STORAGE_KEY = "wijnkelder-flessen-v1";
const NOW = new Date().getFullYear();

const COLORS = ["rood", "wit", "rosé", "mousserend", "versterkt", "oranje"];

const EMPTY = {
  producer: "", name: "", vintage: "", region: "", country: "",
  color: "rood", quantity: 1, location: "",
  purchasePrice: "", retailValue: "", ownValue: "",
  supplier: "", score: "", drinkFrom: "", drinkTo: "", notes: "", tasteNotes: "",
  grape: "", description: "", reviews: "", lat: "", lng: "", placeName: "", imageUrl: "", enriched: false,
};

// which value counts for portfolio math: own estimate if set, else retail
function effVal(b) {
  const hasOwn = b.ownValue !== "" && b.ownValue != null && !isNaN(parseFloat(String(b.ownValue).replace(",", ".")));
  return {
    v: hasOwn ? num(b.ownValue) : num(b.retailValue),
    fallback: !hasOwn && num(b.retailValue) > 0,
    empty: !hasOwn,
  };
}

// ---------- helpers ----------
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
const num = (v) => { const n = parseFloat(String(v).replace(",", ".")); return isNaN(n) ? 0 : n; };
const eur = (n) =>
  new Intl.NumberFormat("nl-BE", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(n || 0);

function drinkStatus(b) {
  const f = parseInt(b.drinkFrom), t = parseInt(b.drinkTo);
  if (!f && !t) return { key: "unknown", label: "—", color: "var(--ink-dim)" };
  if (f && NOW < f) return { key: "wait", label: `vanaf ${f}`, color: "var(--amber)" };
  if (t && NOW > t) return { key: "past", label: "over piek", color: "var(--red)" };
  return { key: "ready", label: "op dronk", color: "var(--green)" };
}

// maturity 0..1 across the window, for the signature bar
function maturity(b) {
  const f = parseInt(b.drinkFrom), t = parseInt(b.drinkTo);
  if (!f || !t || t <= f) return null;
  return Math.max(0, Math.min(1, (NOW - f) / (t - f)));
}

// duplicate detection: same producer + name + vintage (case/space-insensitive)
const dupKey = (b) => [b.producer, b.name, b.vintage].map((x) => String(x ?? "").trim().toLowerCase()).join("|");
function findDuplicate(bottles, b, ignoreId) {
  const k = dupKey(b);
  return bottles.find((x) => x.id !== ignoreId && dupKey(x) === k);
}
// merge an incoming list into a base list, summing quantity for exact duplicates
function mergeLists(base, incoming) {
  const out = base.map((b) => ({ ...b }));
  const index = new Map(out.map((b, i) => [dupKey(b), i]));
  let added = 0, merged = 0;
  for (const inc of incoming) {
    const k = dupKey(inc);
    if (index.has(k)) {
      const i = index.get(k);
      out[i] = { ...out[i], quantity: String((num(out[i].quantity) || 0) + (num(inc.quantity) || 0)) };
      merged++;
    } else { index.set(k, out.length); out.push({ ...inc }); added++; }
  }
  return { list: out, added, merged };
}

// ---------- storage (multi-layer, best-effort) ----------
const LS = (() => {
  try { const k = "__wk_t"; window.localStorage.setItem(k, "1"); window.localStorage.removeItem(k); return window.localStorage; } catch { return null; }
})();
async function rawGet(key) {
  try { if (window.storage) { const r = await window.storage.get(key); if (r && r.value != null) return r.value; } } catch {}
  try { if (LS) { const v = LS.getItem(key); if (v != null) return v; } } catch {}
  return null;
}
async function rawSet(key, value) {
  let ok = false;
  try { if (window.storage) { await window.storage.set(key, value); ok = true; } } catch {}
  try { if (LS) { LS.setItem(key, value); ok = true; } } catch {}
  return ok;
}

function cleanBottle(b) { const { _loading, _error, _confidence, ...rest } = b; return rest; }
function encodeBackup(bottles) {
  const json = JSON.stringify(bottles.map(cleanBottle));
  try { return btoa(unescape(encodeURIComponent(json))); } catch { return json; }
}
function decodeBackup(text) {
  const t = (text || "").trim();
  if (!t) return null;
  try { const j = JSON.parse(decodeURIComponent(escape(atob(t)))); if (Array.isArray(j)) return j; } catch {}
  try { const j = JSON.parse(t); if (Array.isArray(j)) return j; } catch {}
  return null;
}

// ---------- storage ----------
async function loadBottles() {
  try {
    const raw = await rawGet(STORAGE_KEY);
    const list = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(list)) return [];
    return list.map((b) => {
      if (b.retailValue == null && b.currentValue != null) b.retailValue = b.currentValue;
      return { ...EMPTY, ...b };
    });
  } catch { return []; }
}
async function saveBottles(list) {
  return rawSet(STORAGE_KEY, JSON.stringify(list.map(cleanBottle)));
}

// ---------- Excel ----------
const HEADERS = {
  producer: "Producent", name: "Wijn", vintage: "Jaargang", region: "Streek",
  country: "Land", color: "Kleur", grape: "Druif", quantity: "Aantal", location: "Locatie",
  purchasePrice: "Aankoopprijs", retailValue: "Retailwaarde", ownValue: "Eigen waarde",
  supplier: "Leverancier", score: "Score", drinkFrom: "Drink vanaf", drinkTo: "Drink tot", notes: "Notities", tasteNotes: "Proefnotities",
};
const norm = (s) => String(s).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, "");
const IMPORT_MAP = {
  producent: "producer", domein: "producer", producer: "producer",
  wijn: "name", naam: "name", cuvee: "name", name: "name",
  jaargang: "vintage", jaar: "vintage", vintage: "vintage", year: "vintage",
  streek: "region", regio: "region", region: "region", appellation: "region",
  land: "country", country: "country",
  kleur: "color", color: "color", type: "color",
  druif: "grape", druiven: "grape", cepage: "grape", grape: "grape", varietal: "grape",
  aantal: "quantity", quantity: "quantity", qty: "quantity",
  locatie: "location", plaats: "location", rek: "location", location: "location",
  aankoopprijs: "purchasePrice", aankoop: "purchasePrice", purchaseprice: "purchasePrice", cost: "purchasePrice",
  retailwaarde: "retailValue", marktwaarde: "retailValue", retailprijs: "retailValue", huidigewaarde: "retailValue", currentvalue: "retailValue", marketvalue: "retailValue",
  eigenwaarde: "ownValue", eigenwaardeschatting: "ownValue", ownvalue: "ownValue", geschattewaarde: "ownValue",
  waarde: "retailValue", value: "retailValue",
  leverancier: "supplier", supplier: "supplier",
  score: "score", punten: "score",
  drinkvanaf: "drinkFrom", vanaf: "drinkFrom", drinkfrom: "drinkFrom",
  drinktot: "drinkTo", tot: "drinkTo", drinkto: "drinkTo",
  notities: "notes", opmerkingen: "notes", notes: "notes",
  proefnotities: "tasteNotes", proefnota: "tasteNotes", tastingnotes: "tasteNotes", proefnotas: "tasteNotes", degustatie: "tasteNotes",
};

function exportXlsx(bottles) {
  const rows = bottles.map((b) => {
    const o = {};
    for (const k in HEADERS) o[HEADERS[k]] = b[k] ?? "";
    return o;
  });
  const ws = XLSX.utils.json_to_sheet(rows, { header: Object.values(HEADERS) });
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Kelder");
  XLSX.writeFile(wb, `wijnkelder-${new Date().toISOString().slice(0, 10)}.xlsx`);
}
function templateXlsx() {
  const example = {
    Producent: "Château Margaux", Wijn: "Grand Vin", Jaargang: 2015, Streek: "Margaux",
    Land: "Frankrijk", Kleur: "rood", Druif: "Cabernet Sauvignon", Aantal: 3, Locatie: "Rek A – vak 4",
    Aankoopprijs: 480, Retailwaarde: 620, "Eigen waarde": "", Leverancier: "Négociant X", Score: 98,
    "Drink vanaf": 2025, "Drink tot": 2045, Notities: "",
  };
  const ws = XLSX.utils.json_to_sheet([example], { header: Object.values(HEADERS) });
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Kelder");
  XLSX.writeFile(wb, "wijnkelder-template.xlsx");
}
async function parseXlsx(file) {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const raw = XLSX.utils.sheet_to_json(ws, { defval: "" });
  return raw.map((r) => {
    const b = { ...EMPTY, id: uid() };
    for (const key in r) {
      const mapped = IMPORT_MAP[norm(key)];
      if (mapped) b[mapped] = r[key];
    }
    if (!b.quantity) b.quantity = 1;
    if (!COLORS.includes(String(b.color).toLowerCase())) b.color = "rood";
    else b.color = String(b.color).toLowerCase();
    return b;
  }).filter((b) => b.name || b.producer);
}

// ---------- Claude photo analysis ----------
function extractJson(text) {
  let t = text.replace(/```json/gi, "").replace(/```/g, "").trim();
  try { return JSON.parse(t); } catch {}
  const s = t.search(/[\[{]/);
  const eObj = t.lastIndexOf("}"), eArr = t.lastIndexOf("]");
  const e = Math.max(eObj, eArr);
  if (s !== -1 && e !== -1) { try { return JSON.parse(t.slice(s, e + 1)); } catch {} }
  // salvage a truncated object: cut back to the last complete "key": value pair and close braces
  if (s !== -1) {
    let frag = t.slice(s);
    const lastComma = frag.lastIndexOf(",");
    if (lastComma > 0) {
      let candidate = frag.slice(0, lastComma);
      const opens = (candidate.match(/{/g) || []).length;
      const closes = (candidate.match(/}/g) || []).length;
      candidate += "}".repeat(Math.max(0, opens - closes));
      try { return JSON.parse(candidate); } catch {}
    }
  }
  return null;
}

const WINE_SCHEMA = `{
  "producer": "domein/producent",
  "name": "naam van de cuvée",
  "vintage": jaargang als getal of "NV",
  "region": "streek/appellation",
  "country": "land",
  "color": "één van: rood, wit, rosé, mousserend, versterkt, oranje",
  "grape": "druif/druiven met percentages indien gekend, bv. 'Nerello Mascalese 90%, Nerello Cappuccio 10%'",
  "description": "korte beschrijving van de wijn in het Nederlands, 1-2 zinnen",
  "retailPrice": actuele retailprijs per fles in EUR als getal,
  "priceNote": "korte bron/onzekerheid over de prijs",
  "drinkFrom": beste drinkjaar vanaf (getal),
  "drinkTo": beste drinkjaar tot (getal),
  "score": kritiekscore 0-100 indien gekend anders null,
  "confidence": "hoog, midden of laag",
  "notes": "korte relevante nota"
}`;

// images: array of { base64, media } — may be multiple photos (front/back) of the SAME bottle
async function analyzePhoto(images) {
  const imgs = Array.isArray(images) ? images : [images];
  const body = {
    model: "claude-sonnet-4-6",
    max_tokens: 2000,
    tools: [{ type: "web_search_20250305", name: "web_search" }],
    system:
      "Je bent een ervaren sommelier en wijnexpert. De foto's tonen ALLEMAAL DEZELFDE fles (bv. voor- en achteretiket); combineer alle informatie tot één identificatie. " +
      "Wees snel: doe hoogstens één gerichte web search om de actuele retailprijs (EUR, per fles) te controleren; bepaal druif (met percentages indien op het etiket of gekend), drinkvenster en beschrijving uit je eigen kennis. Hou de beschrijving op één korte zin. " +
      "Begin je antwoord met '{' en eindig met '}'. Antwoord UITSLUITEND met het volledige, geldige JSON-object volgens het schema, zonder enige tekst, uitleg of markdown ervoor of erna.",
    messages: [{
      role: "user",
      content: [
        ...imgs.map((im) => ({ type: "image", source: { type: "base64", media_type: im.media, data: im.base64 } })),
        { type: "text", text: `Identificeer deze wijn (alle foto's zijn dezelfde fles) en geef exact dit JSON-object terug:\n${WINE_SCHEMA}` },
      ],
    }],
  };
  const res = await fetch("/api/claude", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  const text = (data.content || []).filter((c) => c.type === "text").map((c) => c.text).join("\n");
  const parsed = extractJson(text);
  if (!parsed) throw new Error("Kon de wijn niet lezen uit dit resultaat.");
  return parsed;
}

// full per-vintage lookup: price, drink window, reviews, description, location — all vintage-specific
async function lookupWineFull(b) {
  const schema = `{
  "grape": "druif/druiven met percentages indien gekend, bv. 'Nerello Mascalese 90%, Nerello Cappuccio 10%'",
  "description": "beschrijving van deze wijn en jaargang in het Nederlands, 2-3 zinnen",
  "retailPrice": actuele retailprijs per fles in EUR voor deze jaargang als getal,
  "drinkFrom": beste drinkjaar vanaf voor deze jaargang (getal),
  "drinkTo": beste drinkjaar tot voor deze jaargang (getal),
  "score": kritiekscore 0-100 voor deze jaargang indien gekend anders null,
  "reviews": "korte samenvatting van recente recensies voor deze jaargang in het Nederlands met bron; 'geen recente recensies gevonden' als er niets is",
  "placeName": "plaats waar de wijn gemaakt wordt (domein, streek, land)",
  "lat": breedtegraad als getal,
  "lng": lengtegraad als getal
}`;
  const wijn = [b.producer, b.name, b.vintage, "-", b.region, b.country].filter(Boolean).join(" ");
  const body = {
    model: "claude-sonnet-4-6",
    max_tokens: 1800,
    tools: [{ type: "web_search_20250305", name: "web_search" }],
    system:
      "Je bent een ervaren sommelier. Zoek de opgegeven wijn en specifieke jaargang op. " +
      "Alle waarden (prijs, drinkvenster, score, recensies, beschrijving) moeten gelden voor die specifieke jaargang. " +
      "Begin met '{' en eindig met '}'. Antwoord UITSLUITEND met het volledige geldige JSON-object volgens het schema, zonder tekst errond of markdown.",
    messages: [{ role: "user", content: `Wijn en jaargang: ${wijn}\n\nGeef exact dit JSON-object terug:\n${schema}` }],
  };
  const res = await fetch("/api/claude", {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
  });
  const data = await res.json();
  const text = (data.content || []).filter((c) => c.type === "text").map((c) => c.text).join("\n");
  const parsed = extractJson(text);
  if (!parsed) throw new Error("Kon jaargang niet opzoeken.");
  return parsed;
}

// map an analysis/search result into a bottle draft
function resultToData(res) {
  return {
    ...EMPTY, id: uid(),
    producer: res.producer || "", name: res.name || "",
    vintage: res.vintage ?? "", region: res.region || "", country: res.country || "",
    color: COLORS.includes(String(res.color).toLowerCase()) ? String(res.color).toLowerCase() : "rood",
    grape: res.grape || "", description: res.description || "",
    quantity: 1, location: "",
    purchasePrice: "", retailValue: res.retailPrice ?? res.retailValue ?? "", ownValue: "",
    supplier: "", score: res.score ?? "",
    drinkFrom: res.drinkFrom ?? "", drinkTo: res.drinkTo ?? "",
    notes: [res.priceNote, res.notes].filter(Boolean).join(" · "),
    _confidence: res.confidence || "",
  };
}

// ==================================================================
export default function App() {
  const [bottles, setBottles] = useState([]);
  const [loaded, setLoaded] = useState(false);
  const [query, setQuery] = useState("");
  const [fColor, setFColor] = useState("");
  const [fStatus, setFStatus] = useState("");
  const [sort, setSort] = useState("producer");
  const [edit, setEdit] = useState(null);          // bottle being edited or new
  const [photoJobs, setPhotoJobs] = useState(null); // array of {id,status,preview,data,error}
  const [importPending, setImportPending] = useState(null);
  const [detail, setDetail] = useState(null);       // bottle being viewed on its card
  const scale = 1;
  const [toast, setToast] = useState("");
  const [savedAt, setSavedAt] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [dupPrompt, setDupPrompt] = useState(null); // { incoming, existing, source }
  const [showBackup, setShowBackup] = useState(false);
  const [showRestore, setShowRestore] = useState(false);
  const [showBulk, setShowBulk] = useState(false);
  const [confirmReq, setConfirmReq] = useState(null); // { message, action }
  const askConfirm = (message, action) => setConfirmReq({ message, action });
  const [bulkInit, setBulkInit] = useState(null);

  const fileImport = useRef();
  const filePhoto = useRef();
  const filePhotoOne = useRef();
  const filePhotoAdd = useRef();
  const [addTarget, setAddTarget] = useState(null);
  const bottlesRef = useRef(bottles);
  useEffect(() => { bottlesRef.current = bottles; }, [bottles]);

  useEffect(() => { loadBottles().then((b) => { setBottles(b); setLoaded(true); }); }, []);
  // single source of truth for saving: persist on every change to bottles
  useEffect(() => {
    if (!loaded) return;
    saveBottles(bottles).then((ok) => { if (ok !== false) setSavedAt(new Date()); });
  }, [bottles, loaded]);
  // extra safety: also save when the app is hidden or closed
  useEffect(() => {
    const save = () => { if (bottlesRef.current.length) saveBottles(bottlesRef.current); };
    const onVis = () => { if (document.hidden) save(); };
    window.addEventListener("pagehide", save);
    document.addEventListener("visibilitychange", onVis);
    return () => { window.removeEventListener("pagehide", save); document.removeEventListener("visibilitychange", onVis); };
  }, []);

  const persist = (next) => setBottles(next);
  // patch a single bottle by id (safe under parallel updates); keeps detail view in sync
  const patchBottle = (id, patch) => {
    setBottles((prev) => prev.map((x) => (x.id === id ? { ...x, ...patch } : x)));
    setDetail((d) => (d && d.id === id ? { ...d, ...patch } : d));
  };
  const flash = (m) => { setToast(m); setTimeout(() => setToast(""), 2600); };

  const countries = useMemo(
    () => [...new Set(bottles.map((b) => b.country).filter(Boolean))].sort(), [bottles]);

  const filtered = useMemo(() => {
    let list = bottles.filter((b) => {
      if (fColor && String(b.color).toLowerCase() !== fColor) return false;
      if (fStatus && drinkStatus(b).key !== fStatus) return false;
      if (query) {
        const q = query.toLowerCase();
        const hay = [b.producer, b.name, b.region, b.country, b.location, b.vintage, b.supplier]
          .join(" ").toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
    const s = sort;
    list = [...list].sort((a, b) => {
      if (s === "value") return effVal(b).v * num(b.quantity) - effVal(a).v * num(a.quantity);
      if (s === "vintage") return num(a.vintage) - num(b.vintage);
      if (s === "drinkTo") return (num(a.drinkTo) || 9999) - (num(b.drinkTo) || 9999);
      return `${a.producer} ${a.name}`.localeCompare(`${b.producer} ${b.name}`);
    });
    return list;
  }, [bottles, query, fColor, fStatus, sort]);

  const stats = useMemo(() => {
    let flessen = 0, cost = 0, value = 0;
    for (const b of bottles) {
      const q = num(b.quantity) || 0;
      flessen += q; cost += num(b.purchasePrice) * q; value += effVal(b).v * q;
    }
    const gain = value - cost;
    const pct = cost > 0 ? (gain / cost) * 100 : 0;
    return { flessen, wijnen: bottles.length, cost, value, gain, pct };
  }, [bottles]);

  // ---- CRUD ----
  const commitNew = (list, b) => [{ ...cleanBottle(b), id: uid() }, ...list];
  // add a new bottle, but stop for confirmation if the same wine already exists
  const addOrPrompt = (b, source) => {
    const cleaned = { ...cleanBottle(b), color: String(b.color || "rood").toLowerCase() };
    const existing = findDuplicate(bottles, cleaned);
    if (existing) { setDupPrompt({ incoming: cleaned, existing, source }); return false; }
    persist(commitNew(bottles, cleaned));
    return true;
  };
  const resolveDup = (action) => {
    const dp = dupPrompt; if (!dp) return;
    if (action === "merge") {
      persist(bottles.map((x) => x.id === dp.existing.id
        ? { ...x, quantity: String((num(x.quantity) || 0) + (num(dp.incoming.quantity) || 1)) } : x));
      flash("Aantal opgeteld bij de bestaande fles.");
    } else if (action === "add") {
      persist(commitNew(bottles, dp.incoming));
      flash("Apart toegevoegd.");
    }
    if (action !== "cancel" && dp.source?.jobId) {
      setPhotoJobs((prev) => { const rest = (prev || []).filter((j) => j.id !== dp.source.jobId); return rest.length ? rest : null; });
    }
    setDupPrompt(null);
  };

  const saveEdit = () => {
    const b = { ...edit };
    if (!b.name && !b.producer) { flash("Naam of producent is verplicht."); return; }
    b.color = String(b.color).toLowerCase();
    if (b.id) { persist(bottles.map((x) => (x.id === b.id ? b : x))); setEdit(null); return; }
    const added = addOrPrompt(b, null);
    setEdit(null);
    if (added) flash("Toegevoegd aan de kelder.");
  };
  const removeBottle = (id) => persist(bottles.filter((b) => b.id !== id));

  // ---- bulk multi-vintage (with per-vintage enrichment) ----
  const enrichVintage = async (b) => {
    try {
      const r = await lookupWineFull(b);
      patchBottle(b.id, {
        grape: b.grape || r.grape || "",
        description: r.description || b.description || "",
        reviews: r.reviews || b.reviews || "",
        placeName: r.placeName || b.placeName || "",
        lat: r.lat ?? b.lat ?? "",
        lng: r.lng ?? b.lng ?? "",
        retailValue: (b.retailValue !== "" && b.retailValue != null) ? b.retailValue : (r.retailPrice ?? ""),
        drinkFrom: b.drinkFrom || (r.drinkFrom ?? ""),
        drinkTo: b.drinkTo || (r.drinkTo ?? ""),
        score: b.score || (r.score ?? ""),
        _loading: false, enriched: true,
      });
    } catch { patchBottle(b.id, { _loading: false }); }
  };
  const addBulk = (shared, rows) => {
    let list = bottles, added = 0, merged = 0;
    const fresh = [];
    rows.forEach((row) => {
      const vintage = String(row.vintage || "").trim();
      const qty = String(row.quantity || "1");
      if (!vintage) return;
      const b = { ...cleanBottle(shared), vintage, quantity: qty, color: String(shared.color || "rood").toLowerCase() };
      const existing = findDuplicate(list, b);
      if (existing) { list = list.map((x) => x.id === existing.id ? { ...x, quantity: String((num(x.quantity) || 0) + (num(qty) || 0)) } : x); merged++; }
      else { const nb = { ...b, id: uid(), enriched: false, _loading: true }; list = [nb, ...list]; fresh.push(nb); added++; }
    });
    persist(list);
    setShowBulk(false);
    flash(`${added} toegevoegd${merged ? `, ${merged} samengevoegd` : ""}. Jaargang-info wordt opgehaald…`);
    fresh.forEach((b) => enrichVintage(b));
  };

  // ---- backup / restore (text, works without downloads) ----
  const doRestore = (text, mode) => {
    const parsed = decodeBackup(text);
    if (!parsed) { flash("Kon deze backup niet lezen."); return; }
    const norml = parsed.map((b) => ({ ...EMPTY, ...b, id: b.id || uid() }));
    if (mode === "replace") {
      const doIt = () => { persist(norml); flash(`${norml.length} flessen hersteld (vervangen).`); setShowRestore(false); };
      if (bottles.length) askConfirm(`Je hele kelder (${bottles.length} wijnen) vervangen door deze backup (${norml.length})?`, doIt);
      else doIt();
    } else {
      const { list, added, merged } = mergeLists(bottles, norml);
      persist(list);
      flash(`${added} hersteld${merged ? `, ${merged} samengevoegd` : ""}.`);
      setShowRestore(false);
    }
  };

  // ---- import ----
  const onImportFile = async (e) => {
    const f = e.target.files?.[0]; if (!f) return;
    try { const rows = await parseXlsx(f); setImportPending(rows); }
    catch { flash("Kon dit bestand niet lezen."); }
    e.target.value = "";
  };
  const applyImport = (mode, rows) => {
    const list = rows || importPending;
    if (mode === "replace") {
      const doIt = () => { persist(list); flash(`${list.length} wijnen geïmporteerd (vervangen).`); setImportPending(null); };
      if (bottles.length) askConfirm(`Je hele kelder (${bottles.length} wijnen) vervangen door deze ${list.length}? Dit kan je niet ongedaan maken.`, doIt);
      else doIt();
    } else {
      const { list: merged, added, merged: mg } = mergeLists(bottles, list);
      persist(merged);
      flash(`${added} toegevoegd${mg ? `, ${mg} samengevoegd` : ""}.`);
      setImportPending(null);
    }
  };

  // ---- photo ----
  const readImageFile = (f) => new Promise((resolve) => {
    const rd = new FileReader();
    rd.onload = () => { const url = rd.result; resolve({ base64: String(url).split(",")[1], media: f.type, preview: url }); };
    rd.readAsDataURL(f);
  });
  const runAnalyze = (jobId, images) => {
    analyzePhoto(images)
      .then((res) => setPhotoJobs((prev) => prev && prev.map((j) => j.id === jobId ? { ...j, status: "done", data: resultToData(res) } : j)))
      .catch((err) => setPhotoJobs((prev) => prev && prev.map((j) => j.id === jobId ? { ...j, status: "error", error: err.message } : j)));
  };
  // default: each selected photo is a separate wine
  const onPhotoFiles = async (e) => {
    const files = [...(e.target.files || [])];
    e.target.value = "";
    if (!files.length) return;
    const jobs = await Promise.all(files.map(async (f) => {
      const im = await readImageFile(f);
      return { id: uid(), status: "pending", images: [im], preview: im.preview, data: null, error: null };
    }));
    setPhotoJobs(jobs);
    jobs.forEach((job) => runAnalyze(job.id, job.images));
  };
  // one wine, several photos (front + back) in a single analysis
  const onPhotoOneFiles = async (e) => {
    const files = [...(e.target.files || [])];
    e.target.value = "";
    if (!files.length) return;
    const imgs = await Promise.all(files.map(readImageFile));
    const job = { id: uid(), status: "pending", images: imgs, preview: imgs[0].preview, data: null, error: null };
    setPhotoJobs([job]);
    runAnalyze(job.id, imgs);
  };
  // add extra photo(s) to an existing job and re-analyze with all of them
  const onAddPhotoToJob = (jobId) => { setAddTarget(jobId); filePhotoAdd.current.click(); };
  const onPhotoAddFiles = async (e) => {
    const files = [...(e.target.files || [])];
    e.target.value = "";
    const jobId = addTarget; setAddTarget(null);
    if (!files.length || !jobId) return;
    const imgs = await Promise.all(files.map(readImageFile));
    let all = imgs;
    setPhotoJobs((prev) => prev && prev.map((j) => {
      if (j.id !== jobId) return j;
      all = [...(j.images || []), ...imgs];
      return { ...j, images: all, preview: j.preview || imgs[0].preview, status: "pending", error: null };
    }));
    runAnalyze(jobId, all);
  };
  const addPhotoResult = (jobId) => {
    const job = photoJobs.find((j) => j.id === jobId);
    if (!job?.data) return;
    const added = addOrPrompt(job.data, { jobId });
    if (added) {
      const rest = photoJobs.filter((j) => j.id !== jobId);
      setPhotoJobs(rest.length ? rest : null);
      flash("Toegevoegd aan de kelder.");
    }
  };

  // ---- update one bottle (used by detail card + enrichment) ----
  const updateBottle = (b) => {
    persist(bottles.map((x) => (x.id === b.id ? b : x)));
    setDetail((d) => (d && d.id === b.id ? b : d));
  };
  const enrichDetail = async (b) => {
    setDetail({ ...b, _loading: true, _error: null });
    try {
      const r = await lookupWineFull(b);
      const patch = {
        grape: b.grape || r.grape || "",
        description: r.description || b.description || "",
        reviews: r.reviews || "",
        placeName: r.placeName || b.placeName || "",
        lat: r.lat ?? b.lat ?? "",
        lng: r.lng ?? b.lng ?? "",
        retailValue: (b.retailValue !== "" && b.retailValue != null) ? b.retailValue : (r.retailPrice ?? ""),
        drinkFrom: b.drinkFrom || (r.drinkFrom ?? ""),
        drinkTo: b.drinkTo || (r.drinkTo ?? ""),
        score: b.score || (r.score ?? ""),
        _loading: false, enriched: true,
      };
      patchBottle(b.id, patch);
    } catch (e) {
      setDetail((d) => (d && d.id === b.id ? { ...d, _loading: false, _error: e.message } : d));
    }
  };

  return (
    <div style={S.app}>
      <style>{CSS}</style>

      {/* ---- header / ledger ---- */}
      <header style={S.header}>
        <div style={S.brandRow}>
          <div style={S.brand}>
            <Wine size={22} strokeWidth={1.5} style={{ color: "var(--wine-bright)" }} />
            <span style={S.brandName}>Kelder</span>
            {savedAt && <span style={S.savedTag}><Check size={11} /> bewaard {savedAt.toLocaleTimeString("nl-BE", { hour: "2-digit", minute: "2-digit" })}</span>}
          </div>
          <div style={S.actions}>
            <button style={S.btnPrimary} onClick={() => filePhoto.current.click()}><Camera size={15} /> Foto</button>
            <button style={S.btnPrimary} onClick={() => setEdit({ ...EMPTY })}><Plus size={15} /> Fles</button>
            <div style={{ position: "relative" }}>
              <button style={S.btnGhost} onClick={() => setMenuOpen((o) => !o)} aria-label="Meer"><MoreHorizontal size={16} /></button>
              {menuOpen && (
                <>
                  <div style={S.menuBackdrop} onClick={() => setMenuOpen(false)} />
                  <div style={S.menu}>
                    <button className="mi" style={S.menuItem} onClick={() => { setMenuOpen(false); filePhotoOne.current.click(); }}><Camera size={15} /> Foto's van 1 fles (voor + achter)</button>
                    <button className="mi" style={S.menuItem} onClick={() => { setMenuOpen(false); setBulkInit(null); setShowBulk(true); }}><Layers size={15} /> Meerdere jaargangen</button>
                    <div style={S.menuSep} />
                    <button className="mi" style={S.menuItem} onClick={() => { setMenuOpen(false); setShowBackup(true); }}><Save size={15} /> Backup (kopieer)</button>
                    <button className="mi" style={S.menuItem} onClick={() => { setMenuOpen(false); setShowRestore(true); }}><Clipboard size={15} /> Herstel (plak)</button>
                    <div style={S.menuSep} />
                    <button className="mi" style={S.menuItem} onClick={() => { setMenuOpen(false); fileImport.current.click(); }}><Upload size={15} /> Excel importeren</button>
                    <button className="mi" style={S.menuItem} onClick={() => { setMenuOpen(false); exportXlsx(bottles); }}><Download size={15} /> Excel exporteren</button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        <div style={S.ledger}>
          <Stat label="In kelder" value={`${stats.flessen} flessen`} sub={`${stats.wijnen} wijnen`} />
          <Stat label="Aankoop" value={eur(stats.cost)} />
          <Stat label="Kelderwaarde" value={eur(stats.value)} accent="gold" />
          <Stat
            label="Ongerealiseerd"
            value={`${stats.gain >= 0 ? "+" : ""}${eur(stats.gain)}`}
            sub={`${stats.gain >= 0 ? "+" : ""}${stats.pct.toFixed(1)}%`}
            accent={stats.gain >= 0 ? "green" : "red"} />
        </div>
      </header>

      {/* ---- toolbar ---- */}
      <div style={S.toolbar}>
        <div style={S.searchWrap}>
          <Search size={16} style={{ color: "var(--ink-dim)" }} />
          <input style={S.search} placeholder="Zoek producent, wijn, streek, locatie…"
            value={query} onChange={(e) => setQuery(e.target.value)} />
        </div>
        <select style={S.select} value={fColor} onChange={(e) => setFColor(e.target.value)}>
          <option value="">Alle kleuren</option>
          {COLORS.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        <select style={S.select} value={fStatus} onChange={(e) => setFStatus(e.target.value)}>
          <option value="">Elke status</option>
          <option value="ready">Op dronk</option>
          <option value="wait">Nog wachten</option>
          <option value="past">Over piek</option>
          <option value="unknown">Geen venster</option>
        </select>
        <select style={S.select} value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="producer">Sorteer: naam</option>
          <option value="value">Sorteer: waarde</option>
          <option value="vintage">Sorteer: jaargang</option>
          <option value="drinkTo">Sorteer: drink tot</option>
        </select>
      </div>

      {/* ---- list ---- */}
      {!loaded ? (
        <div style={S.empty}><Loader2 className="spin" size={22} /> <span>Kelder laden…</span></div>
      ) : filtered.length === 0 ? (
        <EmptyState hasBottles={bottles.length > 0}
          onPhoto={() => filePhoto.current.click()}
          onImport={() => fileImport.current.click()}
          onAdd={() => setEdit({ ...EMPTY })}
          onTemplate={templateXlsx} />
      ) : (
        <div style={S.list}>
          {filtered.map((b) => <Row key={b.id} b={b} scale={scale} onOpen={() => setDetail(b)}
            onDelete={() => askConfirm(`${[b.producer, b.name, b.vintage].filter(Boolean).join(" ")} verwijderen?`, () => { removeBottle(b.id); flash("Verwijderd."); })} />)}
        </div>
      )}

      {/* hidden inputs */}
      <input ref={fileImport} type="file" accept=".xlsx,.xls,.csv" hidden onChange={onImportFile} />
      <input ref={filePhoto} type="file" accept="image/*" multiple hidden onChange={onPhotoFiles} />
      <input ref={filePhotoOne} type="file" accept="image/*" multiple hidden onChange={onPhotoOneFiles} />
      <input ref={filePhotoAdd} type="file" accept="image/*" multiple hidden onChange={onPhotoAddFiles} />

      {/* ---- modals ---- */}
      {detail && <DetailModal b={detail} scale={scale} onClose={() => setDetail(null)}
        onEdit={() => { setEdit(detail); setDetail(null); }}
        onEnrich={() => enrichDetail(detail)} onSave={updateBottle} />}
      {edit && <EditModal edit={edit} setEdit={setEdit} onSave={saveEdit}
        onMultiVintage={(e) => { setBulkInit({ producer: e.producer, name: e.name, region: e.region, country: e.country, color: e.color, grape: e.grape, location: e.location, supplier: e.supplier }); setEdit(null); setShowBulk(true); }} />}
      {importPending && <ImportModal rows={importPending} onApply={applyImport} onCancel={() => setImportPending(null)} />}
      {photoJobs && <PhotoModal jobs={photoJobs} setJobs={setPhotoJobs} onAdd={addPhotoResult} onAddPhoto={onAddPhotoToJob} onClose={() => setPhotoJobs(null)} />}
      {dupPrompt && <DupModal dp={dupPrompt} onResolve={resolveDup} />}
      {showBulk && <BulkModal initial={bulkInit} onAdd={addBulk} onClose={() => setShowBulk(false)} />}
      {showBackup && <BackupModal text={encodeBackup(bottles)} count={bottles.length} onClose={() => setShowBackup(false)} />}
      {showRestore && <RestoreModal onRestore={doRestore} onClose={() => setShowRestore(false)} />}
      {confirmReq && <ConfirmModal message={confirmReq.message}
        onCancel={() => setConfirmReq(null)}
        onConfirm={() => { const a = confirmReq.action; setConfirmReq(null); a(); }} />}

      {toast && <div style={S.toast}>{toast}</div>}
    </div>
  );
}

// ---------- small components ----------
function Stat({ label, value, sub, accent }) {
  const col = accent === "gold" ? "var(--gold)" : accent === "green" ? "var(--green)" : accent === "red" ? "var(--red)" : "var(--ink)";
  return (
    <div style={S.stat}>
      <div style={S.statLabel}>{label}</div>
      <div style={{ ...S.statValue, color: col }}>{value}</div>
      {sub && <div style={{ ...S.statSub, color: accent ? col : "var(--ink-dim)" }}>{sub}</div>}
    </div>
  );
}

function Row({ b, scale, onOpen, onDelete }) {
  const st = drinkStatus(b);
  const m = maturity(b);
  const dot = { rood: "#7B1E2B", wit: "#D9C97A", "rosé": "#E1A0A6", mousserend: "#E7D9A0", versterkt: "#8A4B24", oranje: "#C77D2E" }[b.color] || "#7B1E2B";
  const sc = (px) => Math.round(px * scale);
  const sub = [b.name, b.region].filter(Boolean).join(" · ");
  return (
    <div style={S.row} onClick={onOpen} className="row">
      <div style={{ ...S.colorDot, background: dot, alignSelf: "flex-start", marginTop: sc(6) }} title={b.color} />
      <div style={S.rowMain}>
        <div style={S.rowLine}>
          <span style={{ ...S.producer, fontSize: sc(15), flex: 1, minWidth: 0 }}>{b.producer || b.name || "—"}</span>
          <span style={S.rowLineRight}>
            {b.vintage && <span style={{ ...S.vintage, fontSize: sc(14) }}>{b.vintage}</span>}
            <span style={{ ...S.qtyPill, fontSize: sc(12) }}>{b.quantity || 1}×</span>
          </span>
        </div>
        <div style={S.rowLine}>
          <span style={{ ...S.rowSub, fontSize: sc(13) }}>{sub || "—"}</span>
          <span style={{ ...S.status, color: st.color, fontSize: sc(12) }}>{st.label}</span>
        </div>
        {m !== null ? (
          <div style={{ marginTop: sc(6) }}>
            <div style={{ ...S.matTrack, maxWidth: "100%", marginTop: 0 }}><div style={{ ...S.matNow, left: `${m * 100}%` }} /></div>
            <div style={{ ...S.matYears, maxWidth: "100%", fontSize: sc(11) }}><span>{b.drinkFrom}</span><span>{b.drinkTo}</span></div>
          </div>
        ) : (b.drinkFrom || b.drinkTo) ? (
          <div style={{ ...S.matYears, maxWidth: "100%", fontSize: sc(11), marginTop: sc(5) }}><span>drinkvenster {[b.drinkFrom, b.drinkTo].filter(Boolean).join(" – ")}</span></div>
        ) : null}
        {b.location && <div style={{ ...S.loc, fontSize: sc(11), marginTop: sc(4) }}>📍 {b.location}</div>}
      </div>
      <button className="iconbtn" style={{ ...S.iconBtn, alignSelf: "flex-start" }} onClick={(e) => { e.stopPropagation(); onDelete(); }}><Trash2 size={14} /></button>
    </div>
  );
}

function EmptyState({ hasBottles, onPhoto, onImport, onAdd, onTemplate }) {
  return (
    <div style={S.emptyBig}>
      <Wine size={40} strokeWidth={1} style={{ color: "var(--line)" }} />
      <h2 style={S.emptyTitle}>{hasBottles ? "Niets gevonden" : "Je kelder is nog leeg"}</h2>
      <p style={S.emptyText}>
        {hasBottles ? "Pas je zoekopdracht of filters aan." : "Begin met een foto van een etiket, importeer je Excel, of voeg handmatig toe."}
      </p>
      {!hasBottles && (
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", justifyContent: "center", marginTop: 6 }}>
          <button style={S.btnPrimary} onClick={onPhoto}><Camera size={15} /> Foto analyseren</button>
          <button style={S.btnGhost} onClick={onImport}><Upload size={15} /> Excel importeren</button>
          <button style={S.btnGhost} onClick={onAdd}><Plus size={15} /> Handmatig</button>
          <button style={S.btnLink} onClick={onTemplate}><FileSpreadsheet size={14} /> Template downloaden</button>
        </div>
      )}
    </div>
  );
}

// ---------- edit modal ----------
// ---------- shared bottle form (used by edit + photo review) ----------
function BottleFields({ v, on }) {
  const fld = (k, label, type = "text", w) => (
    <label key={k} style={{ ...S.field, flex: w || 1 }}>
      <span style={S.fieldLabel}>{label}</span>
      <input style={S.input} type={type} value={v[k] ?? ""} onChange={(e) => on(k, e.target.value)} inputMode={type === "number" ? "decimal" : undefined} />
    </label>
  );
  return (
    <div style={S.form}>
      <div style={S.formRow}>{fld("producer", "Producent")}{fld("name", "Wijn / cuvée")}</div>
      <div style={S.formRow}>
        {fld("vintage", "Jaargang", "text", 0.7)}
        <label style={{ ...S.field, flex: 0.9 }}>
          <span style={S.fieldLabel}>Kleur</span>
          <select style={S.input} value={v.color} onChange={(e) => on("color", e.target.value)}>
            {COLORS.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </label>
        <div style={{ ...S.field, flex: 0.9 }}>
          <span style={S.fieldLabel}>Aantal</span>
          <QtyStepper value={v.quantity} onChange={(val) => on("quantity", val)} />
        </div>
      </div>
      <div style={S.formRow}>{fld("grape", "Druif")}{fld("score", "Score", "number", 0.5)}</div>
      <div style={S.formRow}>{fld("region", "Streek")}{fld("country", "Land")}</div>
      <div style={S.formRow}>{fld("location", "Locatie in kelder")}{fld("supplier", "Leverancier")}</div>
      <div style={S.formRow}>{fld("purchasePrice", "Aankoopprijs (€/fles)", "number")}{fld("retailValue", "Retailwaarde (€/fles)", "number")}</div>
      <label style={S.field}>
        <span style={S.fieldLabel}>Eigen geschatte waarde (€/fles)</span>
        <input style={S.input} type="number" inputMode="decimal" value={v.ownValue ?? ""} onChange={(e) => on("ownValue", e.target.value)}
          placeholder={num(v.retailValue) > 0 ? `leeg = retail (${eur(num(v.retailValue))})` : "leeg = retail"} />
      </label>
      <div style={S.formRow}>{fld("drinkFrom", "Drink vanaf", "number")}{fld("drinkTo", "Drink tot", "number")}</div>
      <label style={S.field}>
        <span style={S.fieldLabel}>Mijn proefnotities</span>
        <textarea style={{ ...S.input, minHeight: 110, resize: "vertical", lineHeight: 1.5 }} rows={5} value={v.tasteNotes ?? ""} onChange={(e) => on("tasteNotes", e.target.value)}
          placeholder="Kleur, neus, smaak, evolutie…" />
      </label>
      <label style={S.field}>
        <span style={S.fieldLabel}>Notities</span>
        <textarea style={{ ...S.input, minHeight: 90, resize: "vertical", lineHeight: 1.5 }} rows={4} value={v.notes ?? ""} onChange={(e) => on("notes", e.target.value)} />
      </label>
    </div>
  );
}

// ---------- edit modal ----------
function EditModal({ edit, setEdit, onSave, onMultiVintage }) {
  const set = (k, v) => setEdit({ ...edit, [k]: v });
  const canMulti = edit.producer || edit.name;
  return (
    <Overlay onClose={() => setEdit(null)}>
      <div style={S.modalHead}>
        <h3 style={S.modalTitle}>{edit.id ? "Fles bewerken" : "Nieuwe fles"}</h3>
        <button style={S.iconBtn} onClick={() => setEdit(null)}><X size={18} /></button>
      </div>
      <BottleFields v={edit} on={set} />
      {onMultiVintage && (
        <button style={{ ...S.btnGhost, width: "100%", marginTop: 12, justifyContent: "center" }}
          onClick={() => onMultiVintage(edit)} disabled={!canMulti}>
          <Layers size={15} /> Meerdere jaargangen van deze wijn
        </button>
      )}
      <div style={S.modalFoot}>
        <button style={S.btnGhost} onClick={() => setEdit(null)}>Annuleren</button>
        <button style={S.btnPrimary} onClick={onSave}><Check size={15} /> Opslaan</button>
      </div>
    </Overlay>
  );
}

// ---------- shared quantity stepper ----------
function QtyStepper({ value, onChange, big }) {
  const v = Math.max(0, parseInt(value) || 0);
  const set = (n) => onChange(String(Math.max(0, n)));
  const sz = big ? S.stepBtnBig : S.stepBtn;
  return (
    <div style={S.stepper}>
      <button style={sz} onClick={() => set(v - 1)} aria-label="Minder">−</button>
      <input style={{ ...S.stepInput, width: big ? 52 : 42 }} value={v}
        onChange={(e) => set(parseInt(e.target.value.replace(/\D/g, "")) || 0)}
        inputMode="numeric" />
      <button style={sz} onClick={() => set(v + 1)} aria-label="Meer">+</button>
    </div>
  );
}

// ---------- import modal ----------
function ImportModal({ rows, onApply, onCancel }) {
  const [items, setItems] = useState(rows);
  const setQty = (id, q) => setItems(items.map((b) => (b.id === id ? { ...b, quantity: q } : b)));
  const totaal = items.reduce((s, b) => s + (num(b.quantity) || 0), 0);
  return (
    <Overlay onClose={onCancel} wide>
      <div style={S.modalHead}>
        <h3 style={S.modalTitle}>Import</h3>
        <button style={S.iconBtn} onClick={onCancel}><X size={18} /></button>
      </div>
      <p style={{ ...S.emptyText, textAlign: "left", margin: "0 0 14px" }}>
        <strong style={{ color: "var(--ink)" }}>{items.length}</strong> wijnen · <strong style={{ color: "var(--gold)" }}>{totaal}</strong> flessen. Stel het aantal bij waar nodig.
      </p>
      <div style={S.importList}>
        {items.map((b) => (
          <div key={b.id} style={S.importRow}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={S.rowTop}>
                <span style={S.producer}>{b.producer || b.name || "—"}</span>
                {b.vintage && <span style={S.vintage}>{b.vintage}</span>}
              </div>
              {(b.producer && b.name) && <div style={{ ...S.rowSub }}>{b.name}</div>}
            </div>
            <QtyStepper value={b.quantity} onChange={(q) => setQty(b.id, q)} />
          </div>
        ))}
      </div>
      <div style={S.modalFoot}>
        <button style={S.btnGhost} onClick={onCancel}>Annuleren</button>
        <button style={S.btnGhost} onClick={() => onApply("replace", items)}>Vervangen</button>
        <button style={S.btnPrimary} onClick={() => onApply("append", items)}>Toevoegen</button>
      </div>
    </Overlay>
  );
}

// ---------- photo modal ----------
function PhotoModal({ jobs, setJobs, onAdd, onAddPhoto, onClose }) {
  const [queries, setQueries] = useState({});
  const [searching, setSearching] = useState(null);
  const setData = (id, k, v) => setJobs((prev) => prev.map((j) => j.id === id ? { ...j, data: { ...j.data, [k]: v } } : j));

  const doSearch = async (jobId) => {
    const q = (queries[jobId] || "").trim();
    if (!q) return;
    setSearching(jobId);
    try {
      const res = await searchWineByName(q);
      setJobs((prev) => prev.map((j) => {
        if (j.id !== jobId) return j;
        const d = resultToData(res);
        return {
          ...j, status: "done", error: null,
          data: { ...d, quantity: j.data?.quantity ?? d.quantity, location: j.data?.location ?? "", purchasePrice: j.data?.purchasePrice ?? "", ownValue: j.data?.ownValue ?? "" },
        };
      }));
    } catch (e) {
      setJobs((prev) => prev.map((j) => j.id === jobId ? { ...j, error: e.message } : j));
    } finally { setSearching(null); }
  };

  const SearchRow = ({ job }) => (
    <div style={S.searchRow}>
      <input style={{ ...S.input, flex: 1 }} placeholder="Niet juist? Zoek op naam, bv. Passopisciaro Contrada G 2015"
        value={queries[job.id] || ""} onChange={(e) => setQueries({ ...queries, [job.id]: e.target.value })}
        onKeyDown={(e) => { if (e.key === "Enter") doSearch(job.id); }} />
      <button style={S.btnGhost} onClick={() => doSearch(job.id)} disabled={searching === job.id}>
        {searching === job.id ? <Loader2 className="spin" size={15} /> : <Search size={15} />} Zoek
      </button>
    </div>
  );

  return (
    <Overlay onClose={onClose} wide>
      <div style={S.modalHead}>
        <h3 style={S.modalTitle}>Foto-analyse</h3>
        <button style={S.iconBtn} onClick={onClose}><X size={18} /></button>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 16, maxHeight: "72vh", overflowY: "auto" }}>
        {jobs.map((job) => (
          <div key={job.id} style={S.job}>
            <div style={S.jobTop}>
              <div style={{ position: "relative", flexShrink: 0 }}>
                <img src={job.preview} alt="" style={S.thumb} />
                {job.images && job.images.length > 1 && <span style={S.imgCount}>{job.images.length} foto's</span>}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                {job.status === "pending" && (
                  <div style={S.jobPending}><Loader2 className="spin" size={16} /> Etiket lezen en prijs opzoeken…</div>
                )}
                {job.status !== "pending" && (
                  <div style={S.jobHead}>
                    <span style={S.producer}>{job.data?.producer || job.data?.name || "Niet herkend"}</span>
                    {job.data?._confidence && <span style={S.badge}>zekerheid: {job.data._confidence}</span>}
                  </div>
                )}
                {job.error && <div style={{ ...S.jobError, marginTop: 6 }}><AlertCircle size={15} /> {job.error}</div>}
                {job.status !== "pending" && onAddPhoto && (
                  <button style={{ ...S.btnGhost, marginTop: 8 }} onClick={() => onAddPhoto(job.id)}>
                    <Camera size={15} /> Foto toevoegen (bv. achterkant)
                  </button>
                )}
                {job.status !== "pending" && <SearchRow job={job} />}
              </div>
            </div>

            {job.status !== "pending" && job.data && (
              <>
                <BottleFields v={job.data} on={(k, v) => setData(job.id, k, v)} />
                <button style={{ ...S.btnPrimary, marginTop: 4 }} onClick={() => onAdd(job.id)}>
                  <Check size={15} /> Toevoegen aan kelder
                </button>
              </>
            )}
          </div>
        ))}
      </div>
    </Overlay>
  );
}

function Overlay({ children, onClose, small, wide }) {
  return (
    <div style={S.overlay} onClick={onClose}>
      <div className="modalcard" style={{ ...S.modal, maxWidth: small ? 440 : wide ? 720 : 620 }} onClick={(e) => e.stopPropagation()}>
        {children}
      </div>
    </div>
  );
}

// ---------- generic confirm ----------
function ConfirmModal({ message, onConfirm, onCancel }) {
  return (
    <Overlay onClose={onCancel} small>
      <div style={S.modalHead}><h3 style={S.modalTitle}>Ben je zeker?</h3>
        <button style={S.iconBtn} onClick={onCancel}><X size={18} /></button></div>
      <p style={{ ...S.bodyText, margin: "0 0 18px" }}>{message}</p>
      <div style={S.modalFoot}>
        <button style={S.btnGhost} onClick={onCancel}>Annuleren</button>
        <button style={S.btnPrimary} onClick={onConfirm}><Check size={15} /> Bevestigen</button>
      </div>
    </Overlay>
  );
}

// ---------- duplicate prompt ----------
function DupModal({ dp, onResolve }) {
  const e = dp.existing;
  const label = [e.producer, e.name, e.vintage].filter(Boolean).join(" · ");
  return (
    <Overlay onClose={() => onResolve("cancel")} small>
      <div style={S.modalHead}><h3 style={S.modalTitle}>Staat al in je kelder</h3>
        <button style={S.iconBtn} onClick={() => onResolve("cancel")}><X size={18} /></button></div>
      <p style={{ ...S.bodyText, margin: "0 0 6px" }}>{label || "Deze wijn"} staat er al{e.quantity ? ` (${e.quantity}× ${e.location ? "· " + e.location : ""})` : ""}.</p>
      <p style={{ ...S.bodyText, color: "var(--ink-dim)", margin: "0 0 18px" }}>Wil je het nieuwe aantal ({dp.incoming.quantity || 1}×) optellen, of dit toch als aparte regel toevoegen?</p>
      <div style={S.modalFoot}>
        <button style={S.btnGhost} onClick={() => onResolve("cancel")}>Annuleren</button>
        <button style={S.btnGhost} onClick={() => onResolve("add")}>Apart toevoegen</button>
        <button style={S.btnPrimary} onClick={() => onResolve("merge")}><Check size={15} /> Aantal optellen</button>
      </div>
    </Overlay>
  );
}

// ---------- bulk multi-vintage ----------
function BulkModal({ initial, onAdd, onClose }) {
  const [shared, setShared] = useState({ ...EMPTY, ...(initial || {}) });
  const prefilled = !!(initial && (initial.producer || initial.name));
  const [rows, setRows] = useState([{ vintage: "", quantity: "1" }, { vintage: "", quantity: "1" }, { vintage: "", quantity: "1" }]);
  const [busy, setBusy] = useState(false);
  const set = (k, v) => setShared({ ...shared, [k]: v });
  const setRow = (i, k, v) => setRows(rows.map((r, j) => j === i ? { ...r, [k]: v } : r));
  const addRow = () => setRows([...rows, { vintage: "", quantity: "1" }]);
  const rmRow = (i) => setRows(rows.filter((_, j) => j !== i));
  const filled = rows.filter((r) => String(r.vintage).trim());
  const total = filled.reduce((s, r) => s + (num(r.quantity) || 0), 0);

  const lookup = async () => {
    const q = [shared.producer, shared.name].filter(Boolean).join(" ").trim();
    if (!q) return;
    setBusy(true);
    try {
      const res = await searchWineByName(q);
      const d = resultToData(res);
      setShared((s) => ({ ...s, producer: d.producer || s.producer, name: d.name || s.name, region: d.region || s.region, country: d.country || s.country, color: d.color || s.color, grape: d.grape || s.grape }));
    } catch { /* ignore */ } finally { setBusy(false); }
  };

  const fld = (k, label, w) => (
    <label key={k} style={{ ...S.field, flex: w || 1 }}>
      <span style={S.fieldLabel}>{label}</span>
      <input style={S.input} value={shared[k] ?? ""} onChange={(e) => set(k, e.target.value)} />
    </label>
  );

  return (
    <Overlay onClose={onClose}>
      <div style={S.modalHead}><h3 style={S.modalTitle}>Meerdere jaargangen</h3>
        <button style={S.iconBtn} onClick={onClose}><X size={18} /></button></div>
      <p style={{ ...S.bodyText, color: "var(--ink-dim)", margin: "0 0 14px" }}>
        {prefilled ? "Voeg extra jaargangen toe van deze wijn. " : "Zelfde wijn, in één keer meerdere jaargangen en aantallen. "}
        Prijs, drinkvenster, score en recensies worden daarna per jaargang automatisch opgehaald.
      </p>
      <div style={S.form}>
        <div style={S.formRow}>{fld("producer", "Producent")}{fld("name", "Wijn / cuvée")}</div>
        <div style={S.formRow}>
          <label style={{ ...S.field, flex: 1 }}>
            <span style={S.fieldLabel}>Kleur</span>
            <select style={S.input} value={shared.color} onChange={(e) => set("color", e.target.value)}>
              {COLORS.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </label>
          {fld("grape", "Druif")}
          <button style={{ ...S.btnGhost, alignSelf: "flex-end", height: 40 }} onClick={lookup} disabled={busy}>
            {busy ? <Loader2 className="spin" size={15} /> : <Search size={15} />} Opzoeken
          </button>
        </div>
        <div style={S.formRow}>{fld("region", "Streek")}{fld("country", "Land")}</div>
        <div style={S.formRow}>{fld("location", "Locatie")}{fld("supplier", "Leverancier")}</div>

        <div style={{ ...S.sectionLabel, marginTop: 6 }}>Jaargangen</div>
        {rows.map((r, i) => (
          <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-end" }}>
            <label style={{ ...S.field, flex: 1 }}>
              {i === 0 && <span style={S.fieldLabel}>Jaargang</span>}
              <input style={S.input} placeholder="bv. 2018" value={r.vintage} onChange={(e) => setRow(i, "vintage", e.target.value)} inputMode="numeric" />
            </label>
            <div style={{ ...S.field, flex: "0 0 auto" }}>
              {i === 0 && <span style={S.fieldLabel}>Aantal</span>}
              <QtyStepper value={r.quantity} onChange={(v) => setRow(i, "quantity", v)} />
            </div>
            <button style={{ ...S.iconBtn, marginBottom: 2 }} onClick={() => rmRow(i)} disabled={rows.length <= 1}><Trash2 size={15} /></button>
          </div>
        ))}
        <button style={{ ...S.btnGhost, alignSelf: "flex-start" }} onClick={addRow}><Plus size={15} /> Jaargang toevoegen</button>
      </div>
      <div style={S.modalFoot}>
        <button style={S.btnGhost} onClick={onClose}>Annuleren</button>
        <button style={S.btnPrimary} onClick={() => onAdd(shared, filled)} disabled={!filled.length || (!shared.producer && !shared.name)}>
          <Check size={15} /> {filled.length} jaargangen · {total} flessen toevoegen
        </button>
      </div>
    </Overlay>
  );
}

// ---------- backup / restore ----------
function BackupModal({ text, count, onClose }) {
  const [copied, setCopied] = useState(false);
  const ref = useRef();
  const copy = async () => {
    try { await navigator.clipboard.writeText(text); setCopied(true); }
    catch {
      try { ref.current.select(); document.execCommand("copy"); setCopied(true); } catch { /* user copies manually */ }
    }
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <Overlay onClose={onClose} small>
      <div style={S.modalHead}><h3 style={S.modalTitle}>Backup</h3>
        <button style={S.iconBtn} onClick={onClose}><X size={18} /></button></div>
      <p style={{ ...S.bodyText, color: "var(--ink-dim)", margin: "0 0 12px" }}>
        Kopieer deze tekst en bewaar ze veilig (bv. in Notities of een mail naar jezelf). Met Herstel laad je ze later terug. {count} flessen.
      </p>
      <textarea ref={ref} readOnly value={text} onFocus={(e) => e.target.select()}
        style={{ ...S.input, height: 150, fontFamily: "monospace", fontSize: 11, resize: "vertical" }} />
      <div style={S.modalFoot}>
        <button style={S.btnPrimary} onClick={copy}>{copied ? <Check size={15} /> : <Save size={15} />} {copied ? "Gekopieerd" : "Kopieer"}</button>
      </div>
    </Overlay>
  );
}
function RestoreModal({ onRestore, onClose }) {
  const [text, setText] = useState("");
  return (
    <Overlay onClose={onClose} small>
      <div style={S.modalHead}><h3 style={S.modalTitle}>Herstel</h3>
        <button style={S.iconBtn} onClick={onClose}><X size={18} /></button></div>
      <p style={{ ...S.bodyText, color: "var(--ink-dim)", margin: "0 0 12px" }}>Plak hier een eerder gekopieerde backup.</p>
      <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="Plak je backup-tekst…"
        style={{ ...S.input, height: 150, fontFamily: "monospace", fontSize: 11, resize: "vertical" }} />
      <div style={S.modalFoot}>
        <button style={S.btnGhost} onClick={onClose}>Annuleren</button>
        <button style={S.btnGhost} onClick={() => onRestore(text, "append")} disabled={!text.trim()}>Toevoegen</button>
        <button style={S.btnPrimary} onClick={() => onRestore(text, "replace")} disabled={!text.trim()}><Check size={15} /> Vervangen</button>
      </div>
    </Overlay>
  );
}

// ---------- detail card ----------
function DetailModal({ b, scale, onClose, onEdit, onEnrich, onSave }) {
  const sc = (px) => Math.round(px * scale);
  const st = drinkStatus(b);
  const ev = effVal(b);
  const mat = maturity(b);
  const lat = num(b.lat), lng = num(b.lng);
  const hasCoords = lat !== 0 && lng !== 0;
  const osmLink = hasCoords ? `https://www.openstreetmap.org/?mlat=${lat}&mlon=${lng}#map=9/${lat}/${lng}` : null;

  // auto-enrich first time it's opened
  useEffect(() => { if (!b.enriched && !b._loading && !b._error) onEnrich(); /* eslint-disable-next-line */ }, [b.id]);

  const dot = { rood: "#7B1E2B", wit: "#D9C97A", "rosé": "#E1A0A6", mousserend: "#E7D9A0", versterkt: "#8A4B24", oranje: "#C77D2E" }[b.color] || "#7B1E2B";

  return (
    <Overlay onClose={onClose} wide>
      <div style={S.modalHead}>
        <div style={{ minWidth: 0 }}>
          <div style={S.rowTop}>
            <span style={{ ...S.colorDot, background: dot, width: 9, height: 9 }} />
            <h3 style={{ ...S.modalTitle, fontSize: sc(21) }}>{b.producer || b.name || "Wijn"}</h3>
            {b.vintage && <span style={{ ...S.vintage, fontSize: sc(15) }}>{b.vintage}</span>}
          </div>
          {b.producer && b.name && <div style={{ ...S.rowSub, fontSize: sc(13), marginTop: 2 }}>{b.name}</div>}
        </div>
        <button style={S.iconBtn} onClick={onClose}><X size={18} /></button>
      </div>

      <div style={{ maxHeight: "72vh", overflowY: "auto", display: "flex", flexDirection: "column", gap: 16 }}>
        {/* chips */}
        <div style={S.chips}>
          <span style={{ ...S.chip, fontSize: sc(12) }}>{b.color}</span>
          {b.grape && <span style={{ ...S.chip, fontSize: sc(12) }}>{b.grape}</span>}
          {(b.region || b.country) && <span style={{ ...S.chip, fontSize: sc(12) }}>{[b.region, b.country].filter(Boolean).join(", ")}</span>}
          {b.score && <span style={{ ...S.chip, fontSize: sc(12), color: "var(--gold)", borderColor: "var(--gold)" }}>{b.score}</span>}
          <span style={{ ...S.chip, fontSize: sc(12), color: st.color, borderColor: st.color }}>{st.label}</span>
        </div>

        {/* drink window */}
        {(b.drinkFrom || b.drinkTo) && (
          <div>
            <div style={{ ...S.sectionLabel, fontSize: sc(11) }}>Drinkvenster</div>
            {mat !== null ? (
              <>
                <div style={{ ...S.matTrack, maxWidth: "100%", height: 6 }}><div style={{ ...S.matNow, left: `${mat * 100}%`, height: 12, top: -3 }} /></div>
                <div style={{ ...S.matYears, maxWidth: "100%", fontSize: sc(13), marginTop: 6 }}>
                  <span>{b.drinkFrom}</span>
                  <span style={{ color: st.color, fontWeight: 600 }}>{st.label} · nu {NOW}</span>
                  <span>{b.drinkTo}</span>
                </div>
              </>
            ) : (
              <p style={{ ...S.bodyText, fontSize: sc(14) }}>{[b.drinkFrom, b.drinkTo].filter(Boolean).join(" – ")} <span style={{ color: st.color }}>· {st.label}</span></p>
            )}
          </div>
        )}

        {/* where made */}
        <div>
          <div style={{ ...S.sectionLabel, fontSize: sc(11) }}>Waar gemaakt</div>
          {hasCoords ? (
            <a href={osmLink} target="_blank" rel="noreferrer" style={S.mapPanel}>
              <MapPin size={22} strokeWidth={1.6} style={{ color: "var(--wine-bright)", flexShrink: 0 }} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ ...S.bodyText, fontSize: sc(14), color: "var(--ink)" }}>{b.placeName || "Bekijk de locatie"}</div>
                <div style={{ ...S.mapLink, fontSize: sc(12), marginTop: 3 }}>Open in kaart <ExternalLink size={12} /></div>
              </div>
            </a>
          ) : b._loading ? (
            <div style={{ ...S.mapPlaceholder, fontSize: sc(13) }}><Loader2 className="spin" size={16} /> Locatie opzoeken…</div>
          ) : (
            <div style={{ ...S.mapPlaceholder, fontSize: sc(13) }}>Nog geen locatie. Tik op Vernieuw om op te zoeken.</div>
          )}
        </div>

        {/* description + reviews */}
        <div>
          <div style={{ ...S.sectionLabel, fontSize: sc(11) }}>Beschrijving</div>
          {b._loading && !b.description ? (
            <div style={{ ...S.mapPlaceholder, fontSize: sc(13) }}><Loader2 className="spin" size={16} /> Info ophalen…</div>
          ) : (
            <p style={{ ...S.bodyText, fontSize: sc(14) }}>{b.description || "Nog geen beschrijving."}</p>
          )}
        </div>
        <div>
          <div style={{ ...S.sectionLabel, fontSize: sc(11) }}>Recente recensies</div>
          <p style={{ ...S.bodyText, fontSize: sc(14) }}>{b.reviews || (b._loading ? "…" : "Nog niet opgehaald.")}</p>
        </div>
        {b._error && <div style={{ ...S.jobError, fontSize: sc(13) }}><AlertCircle size={15} /> {b._error}</div>}

        {/* values */}
        <div>
          <div style={{ ...S.sectionLabel, fontSize: sc(11) }}>Waarde per fles</div>
          <div style={S.valGrid}>
            <ValCell label="Aankoop" value={num(b.purchasePrice) > 0 ? eur(num(b.purchasePrice)) : "—"} sc={sc} />
            <ValCell label="Retail" value={num(b.retailValue) > 0 ? eur(num(b.retailValue)) : "—"} sc={sc} />
            <ValCell
              label="Eigen schatting"
              value={ev.empty ? (ev.fallback ? `${eur(ev.v)}*` : "—") : eur(ev.v)}
              sub={ev.fallback ? "niet ingevuld · retail" : ev.empty ? "" : "eigen waarde"}
              muted={ev.fallback}
              sc={sc} />
          </div>
          <div style={{ ...S.mapCaption, fontSize: sc(12), marginTop: 8 }}>
            {b.quantity || 1}× in kelder · totaal {eur(ev.v * (num(b.quantity) || 1))}{ev.fallback ? " (op retail)" : ""}
          </div>
        </div>

        {b.location && <div><div style={{ ...S.sectionLabel, fontSize: sc(11) }}>Locatie</div><p style={{ ...S.bodyText, fontSize: sc(14) }}>{b.location}</p></div>}
        {b.tasteNotes && <div><div style={{ ...S.sectionLabel, fontSize: sc(11) }}>Mijn proefnotities</div><p style={{ ...S.bodyText, fontSize: sc(14), whiteSpace: "pre-wrap" }}>{b.tasteNotes}</p></div>}
        {b.notes && <div><div style={{ ...S.sectionLabel, fontSize: sc(11) }}>Notities</div><p style={{ ...S.bodyText, fontSize: sc(14) }}>{b.notes}</p></div>}
      </div>

      <div style={S.modalFoot}>
        <button style={S.btnGhost} onClick={onEnrich} disabled={b._loading}>
          {b._loading ? <Loader2 className="spin" size={15} /> : <Search size={15} />} Vernieuw
        </button>
        <button style={S.btnPrimary} onClick={onEdit}><Pencil size={15} /> Bewerken</button>
      </div>
    </Overlay>
  );
}
function ValCell({ label, value, sub, muted, sc }) {
  return (
    <div style={S.valCell}>
      <div style={{ ...S.valCellLabel, fontSize: sc(11) }}>{label}</div>
      <div style={{ ...S.valCellValue, fontSize: sc(17), color: muted ? "var(--ink-dim)" : "var(--ink)", fontStyle: muted ? "italic" : "normal" }}>{value}</div>
      {sub && <div style={{ ...S.valCellSub, fontSize: sc(10) }}>{sub}</div>}
    </div>
  );
}

// ==================== styles ====================
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Spectral:ital,wght@0,400;0,500;0,600;1,400&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap');
* { box-sizing: border-box; }
:root{
  --bg:#12100E; --bg2:#1B1714; --bg3:#241F1B; --bg4:#2E2823;
  --line:#38302A; --line2:#473D35;
  --ink:#EEE7DC; --ink2:#CFC4B5; --ink-dim:#9C8F7F;
  --wine:#7A1F2B; --wine-bright:#A83544; --wine-glow:rgba(168,53,68,.28);
  --gold:#C9A24B; --gold-dim:#8E7434;
  --green:#8AA84B; --amber:#D2A049; --red:#C6553B;
}
html,body{margin:0;background:#12100E;-webkit-text-size-adjust:100%;text-size-adjust:100%;}
.spin{animation:spin 1s linear infinite;}
@keyframes spin{to{transform:rotate(360deg);}}
@keyframes fadeUp{from{opacity:0;transform:translateY(6px);}to{opacity:1;transform:none;}}
.row{position:relative;transition:background .14s ease, box-shadow .14s ease;}
.row:before{content:"";position:absolute;left:0;top:0;bottom:0;width:2px;background:transparent;transition:background .14s ease;}
.row:hover{background:var(--bg2)!important;}
.row:hover:before{background:var(--wine-bright);}
.iconbtn:hover{background:var(--bg3)!important;color:var(--ink)!important;}
.mi:hover{background:var(--bg3)!important;}
button{transition:filter .12s ease, background .12s ease, border-color .12s ease;}
button:not(.iconbtn):not(:disabled):hover{filter:brightness(1.08);}
.chip{transition:border-color .12s;}
input,select,textarea{font-family:inherit;}
input:focus,select:focus,textarea:focus{outline:none;border-color:var(--wine-bright)!important;box-shadow:0 0 0 3px var(--wine-glow);}
::placeholder{color:var(--ink-dim);}
::-webkit-scrollbar{width:9px;height:9px;} ::-webkit-scrollbar-thumb{background:var(--line2);border-radius:5px;} ::-webkit-scrollbar-track{background:transparent;}
button:disabled{opacity:.4;cursor:default;}
.modalcard{animation:fadeUp .18s ease both;}
`;

const S = {
  app: {
    minHeight: "100vh", color: "var(--ink)", fontFamily: "'Inter',system-ui,sans-serif", fontSize: 14, paddingBottom: 60,
    background: "radial-gradient(120% 80% at 50% -10%, #221A16 0%, #16120F 45%, #100E0C 100%)",
  },
  header: { position: "sticky", top: 0, zIndex: 10, background: "linear-gradient(180deg, rgba(20,16,13,.96), rgba(20,16,13,.82))", backdropFilter: "blur(8px)", borderBottom: "1px solid var(--line)", padding: "16px 22px 0" },
  brandRow: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap" },
  brand: { display: "flex", alignItems: "center", gap: 11 },
  brandName: { fontFamily: "'Spectral',serif", fontSize: 27, fontWeight: 600, letterSpacing: 0.4, color: "var(--ink)" },
  savedTag: { display: "inline-flex", alignItems: "center", gap: 4, fontSize: 11, color: "var(--green)", background: "rgba(127,163,75,.12)", border: "1px solid rgba(127,163,75,.3)", padding: "2px 8px", borderRadius: 20, whiteSpace: "nowrap" },
  menuBackdrop: { position: "fixed", inset: 0, zIndex: 40 },
  menu: { position: "absolute", right: 0, top: 44, zIndex: 41, background: "var(--bg2)", border: "1px solid var(--line2)", borderRadius: 12, padding: 6, minWidth: 210, boxShadow: "0 16px 40px rgba(0,0,0,.5)", display: "flex", flexDirection: "column", gap: 2 },
  menuItem: { display: "flex", alignItems: "center", gap: 9, background: "transparent", border: "none", color: "var(--ink)", padding: "10px 12px", borderRadius: 8, fontSize: 13.5, cursor: "pointer", textAlign: "left", width: "100%" },
  menuSep: { height: 1, background: "var(--line)", margin: "4px 6px" },
  actions: { display: "flex", gap: 8, flexWrap: "wrap" },
  ledger: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: "12px 16px", padding: "16px 0 14px" },
  stat: { minWidth: 0 },
  statLabel: { fontSize: 10.5, textTransform: "uppercase", letterSpacing: 1.4, color: "var(--ink-dim)", marginBottom: 4 },
  statValue: { fontFamily: "'JetBrains Mono',monospace", fontSize: 18, fontWeight: 500, whiteSpace: "nowrap", letterSpacing: -0.3 },
  statSub: { fontFamily: "'JetBrains Mono',monospace", fontSize: 12, marginTop: 2 },

  toolbar: { display: "flex", gap: 8, padding: "16px 22px", flexWrap: "wrap", alignItems: "center" },
  searchWrap: { display: "flex", alignItems: "center", gap: 8, background: "var(--bg2)", border: "1px solid var(--line)", borderRadius: 10, padding: "0 13px", flex: "1 1 260px", height: 40 },
  search: { border: "none", background: "transparent", color: "var(--ink)", flex: 1, fontSize: 16 },
  select: { background: "var(--bg2)", border: "1px solid var(--line)", borderRadius: 10, color: "var(--ink2)", height: 40, padding: "0 12px", fontSize: 16, cursor: "pointer" },

  list: { padding: "4px 12px 0" },
  row: { display: "flex", alignItems: "flex-start", gap: 12, padding: "13px 10px 14px 12px", borderBottom: "1px solid var(--bg3)", cursor: "pointer" },
  colorDot: { width: 9, height: 9, borderRadius: "50%", flexShrink: 0, boxShadow: "0 0 0 1px rgba(255,255,255,.1), 0 0 8px rgba(0,0,0,.4)" },
  rowMain: { flex: 1, minWidth: 0, display: "flex", flexDirection: "column", gap: 2 },
  rowLine: { display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: 10 },
  rowLineRight: { display: "flex", alignItems: "center", gap: 8, flexShrink: 0 },
  qtyPill: { fontFamily: "'JetBrains Mono',monospace", fontSize: 12, color: "var(--ink2)", background: "var(--bg3)", border: "1px solid var(--line)", padding: "1px 8px", borderRadius: 20, whiteSpace: "nowrap" },
  rowTop: { display: "flex", alignItems: "baseline", gap: 9 },
  producer: { fontFamily: "'Spectral',serif", fontWeight: 600, fontSize: 16, letterSpacing: 0.2, color: "var(--ink)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" },
  vintage: { fontFamily: "'JetBrains Mono',monospace", fontSize: 14, color: "var(--gold)", letterSpacing: 0.5 },
  rowSub: { fontSize: 13, color: "var(--ink2)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", flex: 1, minWidth: 0 },
  dim: { color: "var(--ink-dim)" },
  matTrack: { position: "relative", height: 4, borderRadius: 3, marginTop: 9, maxWidth: 240, background: "linear-gradient(90deg, var(--amber) 0%, var(--green) 50%, var(--red) 100%)", opacity: 0.85 },
  matWrap: { marginTop: 2 },
  matYears: { display: "flex", justifyContent: "space-between", maxWidth: 240, marginTop: 3, fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: "var(--ink-dim)", letterSpacing: 0.3 },
  matNow: { position: "absolute", top: -3, width: 3, height: 10, borderRadius: 2, background: "var(--ink)", boxShadow: "0 0 0 2px var(--bg), 0 0 6px rgba(0,0,0,.6)", transform: "translateX(-50%)" },
  matFill: { height: "100%", borderRadius: 3 },
  rowMeta: { width: 118, flexShrink: 0, textAlign: "right" },
  status: { fontSize: 12, fontWeight: 600, whiteSpace: "nowrap", letterSpacing: 0.2 },
  loc: { fontSize: 12, color: "var(--ink-dim)", marginTop: 3, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" },
  rowNums: { width: 98, flexShrink: 0, textAlign: "right" },
  qty: { fontFamily: "'JetBrains Mono',monospace", fontSize: 13, color: "var(--ink-dim)" },
  val: { fontFamily: "'JetBrains Mono',monospace", fontSize: 14, color: "var(--ink)", marginTop: 3, letterSpacing: -0.2 },
  rowBtns: { display: "flex", gap: 2, flexShrink: 0 },
  iconBtn: { background: "transparent", border: "none", color: "var(--ink-dim)", width: 32, height: 32, borderRadius: 8, cursor: "pointer", display: "grid", placeItems: "center" },

  empty: { display: "flex", alignItems: "center", justifyContent: "center", gap: 10, padding: 60, color: "var(--ink-dim)" },
  emptyBig: { display: "flex", flexDirection: "column", alignItems: "center", gap: 10, padding: "60px 20px", textAlign: "center" },
  emptyTitle: { fontFamily: "'Spectral',serif", fontSize: 22, fontWeight: 500, margin: "8px 0 0" },
  emptyText: { color: "var(--ink-dim)", maxWidth: 420, lineHeight: 1.5, margin: 0 },

  btnPrimary: { display: "inline-flex", alignItems: "center", gap: 6, background: "linear-gradient(180deg, var(--wine-bright), var(--wine))", border: "1px solid var(--wine-bright)", color: "#fff", padding: "0 15px", height: 38, borderRadius: 10, fontSize: 13, fontWeight: 600, cursor: "pointer", boxShadow: "0 1px 2px rgba(0,0,0,.3)" },
  btnGhost: { display: "inline-flex", alignItems: "center", gap: 6, background: "var(--bg2)", border: "1px solid var(--line)", color: "var(--ink2)", padding: "0 15px", height: 38, borderRadius: 10, fontSize: 13, fontWeight: 500, cursor: "pointer" },
  btnLink: { display: "inline-flex", alignItems: "center", gap: 6, background: "transparent", border: "none", color: "var(--gold)", fontSize: 13, cursor: "pointer" },

  overlay: { position: "fixed", inset: 0, background: "rgba(6,4,3,.74)", backdropFilter: "blur(3px)", display: "grid", placeItems: "center", padding: 16, zIndex: 50 },
  modal: { width: "100%", background: "linear-gradient(180deg, #201B17, #1A1613)", border: "1px solid var(--line2)", borderRadius: 16, padding: 22, maxHeight: "90vh", overflowY: "auto", boxShadow: "0 30px 80px rgba(0,0,0,.6)" },
  modalHead: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12, marginBottom: 18 },
  modalTitle: { fontFamily: "'Spectral',serif", fontSize: 21, fontWeight: 600, margin: 0, letterSpacing: 0.2 },
  form: { display: "flex", flexDirection: "column", gap: 13 },
  formRow: { display: "flex", gap: 10, flexWrap: "wrap" },
  field: { display: "flex", flexDirection: "column", gap: 6, flex: 1, minWidth: 130 },
  fieldLabel: { fontSize: 10.5, textTransform: "uppercase", letterSpacing: 0.8, color: "var(--ink-dim)" },
  input: { background: "var(--bg)", border: "1px solid var(--line)", borderRadius: 9, color: "var(--ink)", padding: "10px 12px", fontSize: 16, width: "100%" },
  modalFoot: { display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 20 },

  stepper: { display: "inline-flex", alignItems: "center", gap: 6, flexShrink: 0 },
  stepBtn: { width: 36, height: 36, borderRadius: 9, border: "1px solid var(--line2)", background: "var(--bg3)", color: "var(--ink)", fontSize: 20, lineHeight: 1, cursor: "pointer", display: "grid", placeItems: "center", userSelect: "none" },
  stepBtnBig: { width: 42, height: 42, borderRadius: 10, border: "1px solid var(--wine-bright)", background: "linear-gradient(180deg, var(--wine-bright), var(--wine))", color: "#fff", fontSize: 22, lineHeight: 1, cursor: "pointer", display: "grid", placeItems: "center", userSelect: "none" },
  stepInput: { height: 36, textAlign: "center", background: "var(--bg)", border: "1px solid var(--line)", borderRadius: 9, color: "var(--ink)", fontFamily: "'JetBrains Mono',monospace", fontSize: 16, fontWeight: 500 },
  importList: { display: "flex", flexDirection: "column", maxHeight: "58vh", overflowY: "auto", border: "1px solid var(--line)", borderRadius: 12, background: "var(--bg)" },
  importRow: { display: "flex", alignItems: "center", gap: 12, padding: "11px 15px", borderBottom: "1px solid var(--bg3)" },

  job: { display: "flex", flexDirection: "column", gap: 14, padding: 15, background: "var(--bg)", border: "1px solid var(--line)", borderRadius: 12 },
  jobTop: { display: "flex", gap: 15, alignItems: "flex-start" },
  searchRow: { display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" },
  thumb: { width: 82, height: 104, objectFit: "cover", borderRadius: 9, flexShrink: 0, border: "1px solid var(--line2)" },
  imgCount: { position: "absolute", bottom: 4, left: 4, fontSize: 10, background: "rgba(0,0,0,.7)", color: "#fff", padding: "1px 6px", borderRadius: 10, border: "1px solid var(--line2)" },
  jobPending: { display: "flex", alignItems: "center", gap: 8, color: "var(--ink-dim)", padding: "20px 0" },
  jobError: { display: "flex", alignItems: "center", gap: 8, color: "var(--red)", padding: "20px 0" },
  jobHead: { display: "flex", alignItems: "center", gap: 10, marginBottom: 11, flexWrap: "wrap" },
  badge: { fontSize: 11, background: "var(--bg3)", color: "var(--ink-dim)", padding: "3px 9px", borderRadius: 20, border: "1px solid var(--line)" },
  miniGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 9 },
  photoDesc: { fontSize: 13, color: "var(--ink2)", lineHeight: 1.55, margin: "10px 0 0" },

  textSize: { display: "inline-flex", border: "1px solid var(--line)", borderRadius: 10, overflow: "hidden", height: 38, background: "var(--bg2)" },
  tsBtn: { width: 36, background: "transparent", border: "none", color: "var(--ink2)", cursor: "pointer", display: "grid", placeItems: "center", lineHeight: 1, fontFamily: "'Spectral',serif" },

  chips: { display: "flex", flexWrap: "wrap", gap: 7 },
  chip: { fontSize: 12, border: "1px solid var(--line2)", color: "var(--ink2)", padding: "4px 11px", borderRadius: 20, background: "var(--bg2)", textTransform: "capitalize", letterSpacing: 0.2 },
  sectionLabel: { fontSize: 10.5, textTransform: "uppercase", letterSpacing: 1.4, color: "var(--gold-dim)", marginBottom: 8, fontWeight: 600 },
  bottleImg: { width: 78, height: 130, objectFit: "cover", borderRadius: 10, border: "1px solid var(--line2)", background: "var(--bg)", flexShrink: 0 },
  map: { width: "100%", height: 210, border: "1px solid var(--line2)", borderRadius: 12, background: "var(--bg)", display: "block", objectFit: "cover", cursor: "pointer" },
  mapFoot: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, marginTop: 8, flexWrap: "wrap" },
  mapPanel: { display: "flex", alignItems: "center", gap: 12, padding: "14px 16px", background: "var(--bg)", border: "1px solid var(--line2)", borderRadius: 12, textDecoration: "none", cursor: "pointer" },
  mapLink: { display: "inline-flex", alignItems: "center", gap: 4, color: "var(--gold)", fontSize: 12, textDecoration: "none", whiteSpace: "nowrap" },
  mapCaption: { fontSize: 12, color: "var(--ink-dim)" },
  mapPlaceholder: { display: "flex", alignItems: "center", gap: 8, fontSize: 13, color: "var(--ink-dim)", background: "var(--bg)", border: "1px dashed var(--line2)", borderRadius: 12, padding: "20px 15px" },
  bodyText: { fontSize: 14, lineHeight: 1.65, color: "var(--ink2)", margin: 0 },
  valGrid: { display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 9 },
  valCell: { background: "var(--bg)", border: "1px solid var(--line)", borderRadius: 12, padding: "11px 13px", minWidth: 0 },
  valCellLabel: { fontSize: 11, textTransform: "uppercase", letterSpacing: 0.6, color: "var(--ink-dim)", marginBottom: 4 },
  valCellValue: { fontFamily: "'JetBrains Mono',monospace", fontSize: 17, fontWeight: 500, whiteSpace: "nowrap" },
  valCellSub: { fontSize: 10, color: "var(--ink-dim)", marginTop: 3 },

  toast: { position: "fixed", bottom: 20, left: "50%", transform: "translateX(-50%)", background: "var(--bg3)", border: "1px solid var(--line)", color: "var(--ink)", padding: "10px 18px", borderRadius: 10, fontSize: 13, zIndex: 60, boxShadow: "0 8px 30px rgba(0,0,0,.4)" },
};

// ---- PWA mount ----
import { createRoot } from "react-dom/client";
const rootEl = document.getElementById("root");
if (rootEl) createRoot(rootEl).render(<App />);
