# Kelder — je wijnkelder als app op je iPhone

Dit pakket zet je wijnkelder-app online als echte app op je iPhone-startscherm.
Geen App Store nodig. Updates kunnen altijd, je kelder-data blijft staan.

## Wat je eenmalig nodig hebt (±20 minuten, alles via je browser)

1. Een gratis **GitHub**-account (github.com)
2. Een gratis **Vercel**-account (vercel.com, meld aan met je GitHub-account)
3. Een **Anthropic API-sleutel** voor de foto-analyse (console.anthropic.com
   → API Keys → Create Key). Zet er een klein tegoed op; reken op enkele
   centen per foto-analyse.

## Stap 1 — Zet de bestanden op GitHub

1. Ga naar github.com → New repository → naam bv. `kelder` → Private → Create.
2. Klik "uploading an existing file" en sleep ALLE bestanden en mappen uit
   dit pakket erin (de mappen `public` en `api`, plus `package.json` en
   `vercel.json`). Commit.

## Stap 2 — Zet de app online met Vercel

1. Ga naar vercel.com → Add New → Project → kies je `kelder`-repository.
2. Bij Environment Variables: voeg toe
   - Name: `ANTHROPIC_API_KEY`
   - Value: (plak je Anthropic-sleutel)
3. Klik Deploy. Na een minuut krijg je een adres zoals
   `https://kelder-xxxx.vercel.app`.

## Stap 3 — Zet de app op je iPhone

1. Open dat adres in **Safari** op je iPhone.
2. Tik op de deelknop (vierkant met pijl) → **Zet op beginscherm**.
3. Je hebt nu een echt Kelder-icoon. De app opent volledig scherm.

## Je data

- Alles wordt automatisch lokaal op je iPhone bewaard en blijft staan bij
  updates van de app.
- Gebruik af en toe **menu → Backup (kopieer)** en bewaar die tekst in
  Notities. Dat is je vangnet, ook als je ooit van toestel wisselt
  (dan: menu → Herstel (plak) op het nieuwe toestel).

## Een update uitrollen (zonder dataverlies)

1. Vervang in je GitHub-repository het bestand `public/app.js` (en eventueel
   andere gewijzigde bestanden) door de nieuwe versie: open het bestand op
   github.com → potloodje/Upload → commit.
2. Vercel zet de nieuwe versie automatisch live.
3. Open de app op je iPhone; de nieuwe versie laadt vanzelf.
   Je kelder-data wordt hierbij nooit geraakt (die staat los van de app-code).

Tip: verhoog bij een update ook het versienummer in `public/sw.js`
(`kelder-v1` → `kelder-v2`), dan is de nieuwe versie gegarandeerd meteen
zichtbaar.

## Voor later (ontwikkelen in Claude Code)

Deze map is een gewoon codeproject. Open ze in Claude Code en je kan er
direct mee verder: `npm install` en `npm run build` bouwen `public/app.js`
opnieuw uit `app.jsx`.
